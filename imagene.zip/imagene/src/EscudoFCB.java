
package escudofcb;



public class EscudoFCB {
    // Atributos
    private String forma;
    private String colorPrimario;
    private String colorSecundario;
    private String lema;
    private String simbolo;

    // Constructor
    public EscudoFCB(String forma, String colorPrimario, String colorSecundario, String lema, String simbolo) {
        this.forma = forma;
        this.colorPrimario = colorPrimario;
        this.colorSecundario = colorSecundario;
        this.lema = lema;
        this.simbolo = simbolo;
    }

    // Getters y Setters
    public String getForma() {
        return forma;
    }

    public void setForma(String forma) {
        this.forma = forma;
    }

    public String getColorPrimario() {
        return colorPrimario;
    }

    public void setColorPrimario(String colorPrimario) {
        this.colorPrimario = colorPrimario;
    }

    public String getColorSecundario() {
        return colorSecundario;
    }

    public void setColorSecundario(String colorSecundario) {
        this.colorSecundario = colorSecundario;
    }

    public String getLema() {
        return lema;
    }

    public void setLema(String lema) {
        this.lema = lema;
    }

    public String getSimbolo() {
        return simbolo;
    }

    public void setSimbolo(String simbolo) {
        this.simbolo = simbolo;
    }

    // M�todos
    public void mostrarEscudo() {
        System.out.println("Escudo del FC Barcelona:");
        System.out.println("Forma: " + forma);
        System.out.println("Colores: " + colorPrimario + ", " + colorSecundario);
        System.out.println("Lema: " + lema);
        System.out.println("S�mbolo: " + simbolo);
    }

    public void cambiarColor(String nuevoColorPrimario, String nuevoColorSecundario) {
        this.colorPrimario = nuevoColorPrimario;
        this.colorSecundario = nuevoColorSecundario;
        System.out.println("Colores del escudo actualizados.");
    }

    public void agregarLema(String nuevoLema) {
        this.lema = nuevoLema;
        System.out.println("Nuevo lema agregado: " + nuevoLema);
    }

    public void cambiarSimbolo(String nuevoSimbolo) {
        this.simbolo = nuevoSimbolo;
        System.out.println("Nuevo s�mbolo: " + nuevoSimbolo);
    }

    public void mostrarDetalles() {
        System.out.println("Escudo del FC Barcelona, con forma: " + forma + " y colores: " + colorPrimario + " y " + colorSecundario);
    }
}

// Clase Color
public class Color {
    // Atributos
    private String colorPrimario;
    private String colorSecundario;

    // Constructor
    public Color(String colorPrimario, String colorSecundario) {
        this.colorPrimario = colorPrimario;
        this.colorSecundario = colorSecundario;
    }

    // Getters y Setters
    public String getColorPrimario() {
        return colorPrimario;
    }

    public void setColorPrimario(String colorPrimario) {
        this.colorPrimario = colorPrimario;
    }

    public String getColorSecundario() {
        return colorSecundario;
    }

    public void setColorSecundario(String colorSecundario) {
        this.colorSecundario = colorSecundario;
    }

    // M�todos
    public void mostrarColores() {
        System.out.println("Colores: " + colorPrimario + " y " + colorSecundario);
    }

    public void actualizarColores(String nuevoColorPrimario, String nuevoColorSecundario) {
        this.colorPrimario = nuevoColorPrimario;
        this.colorSecundario = nuevoColorSecundario;
        System.out.println("Colores actualizados.");
    }

    public void invertColores() {
        String temp = colorPrimario;
        colorPrimario = colorSecundario;
        colorSecundario = temp;
        System.out.println("Colores invertidos.");
    }

    public void cambiarColorSecundario(String nuevoColorSecundario) {
        this.colorSecundario = nuevoColorSecundario;
        System.out.println("Nuevo color secundario: " + nuevoColorSecundario);
    }

    public void mostrarColorPrincipal() {
        System.out.println("Color principal: " + colorPrimario);
    }
}

// Clase Letras
public class Letras {
    // Atributos
    private String lema;
    private String simbolo;

    // Constructor
    public Letras(String lema, String simbolo) {
        this.lema = lema;
        this.simbolo = simbolo;
    }

    // Getters y Setters
    public String getLema() {
        return lema;
    }

    public void setLema(String lema) {
        this.lema = lema;
    }

    public String getSimbolo() {
        return simbolo;
    }

    public void setSimbolo(String simbolo) {
        this.simbolo = simbolo;
    }

    // M�todos
    public void mostrarLema() {
        System.out.println("Lema: " + lema);
    }

    public void actualizarSimbolo(String nuevoSimbolo) {
        this.simbolo = nuevoSimbolo;
        System.out.println("Simbolo actualizado a: " + nuevoSimbolo);
    }

    public void cambiarLema(String nuevoLema) {
        this.lema = nuevoLema;
        System.out.println("Nuevo lema: " + nuevoLema);
    }

    public void mostrarSimbolo() {
        System.out.println("S�mbolo: " + simbolo);
    }

    public void imprimirDetalles() {
        System.out.println("Detalles de letras: Lema = " + lema + ", S�mbolo = " + simbolo);
    }
}

}