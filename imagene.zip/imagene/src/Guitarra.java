package guitarra;

public class Guitarra {
    
    
     private String nombre;
    private int edad;
    private String instrumento;
    private int numero_de_cuerdas;
    private int acordes;

    // Constructor
    public Guitarra(String nombre, int acordes , int edad, String instrumento,int numero_de_cuerdas) {
        this.nombre = nombre;
        this.acordes = acordes;
        this.edad = edad;
        this.instrumento = instrumento;
        this.numero_de_cuerdas = numero_de_cuerdas;
     
        
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }
    
    public int getAcordes() {
        return acordes;
    }
    public void setAcordes(int acordes){
        this.acordes = acordes;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    public int getNumero_de_cuerdas() {
        return numero_de_cuerdas;
    }
    
    public void setNumero_de_cuerdas(int numero_de_cuerdas) {
        this.numero_de_cuerdas = numero_de_cuerdas;
    }

    public String getInstrumento() {
        return instrumento;
    }

    public void setInstrumento(String instrumento) {
        this.instrumento = instrumento;
    }

    // M�todo 
    public void imprimirInfo() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad);
        System.out.println("Instrumento: " + instrumento);
        System.out.println("Numero de cuerdas: " + numero_de_cuerdas);
        System.out.println("Acordes: " + acordes);
    }

    // M�todo de ejemplo
    public void tocarInstrumento() {
        System.out.println(nombre + " est� tocando " + instrumento );
    }
    
   
    
}
