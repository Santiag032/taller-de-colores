
package clase;
public class Pelota {
    // Atributos
    private String color;
    private double diametro;
    private String material;
    private double peso;
    private String tipo; // Ej: f�tbol, b�squet, tenis

    // Constructor
    public Pelota(String color, double diametro, String material, double peso, String tipo) {
        this.color = color;
        this.diametro = diametro;
        this.material = material;
        this.peso = peso;
        this.tipo = tipo;
    }

    // Getters y Setters
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }

    public double getDiametro() { return diametro; }
    public void setDiametro(double diametro) { this.diametro = diametro; }

    public String getMaterial() { return material; }
    public void setMaterial(String material) { this.material = material; }

    public double getPeso() { return peso; }
    public void setPeso(double peso) { this.peso = peso; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    // M�todos adicionales
    public void rebotar() {
        System.out.println("La pelota rebota...");
    }

    public void rodar() {
        System.out.println("La pelota est� rodando.");
    }

    public void inflar(double cantidad) {
        System.out.println("Inflando la pelota con " + cantidad + " PSI.");
    }

    public void mostrarInformacion() {
        System.out.println("Pelota de " + tipo + " - Color: " + color + ", Di�metro: " + diametro + " cm");
    }

    public boolean esReglamentaria() {
        return (peso >= 0.4 && peso <= 0.6); // Ejemplo de peso reglamentario
    }
}