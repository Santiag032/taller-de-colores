package reloj;

public class Reloj {
    private String marca;
    private int hora;
    private int minuto;
    private int segundo;
    private boolean esDigital;

    public Reloj(String marca, int hora, int minuto, int segundo, boolean esDigital) {
        this.marca = marca;
        this.hora = hora;
        this.minuto = minuto;
        this.segundo = segundo;
        this.esDigital = esDigital;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getHora() {
        return hora;
    }

    public void setHora(int hora) {
        if (hora >= 0 && hora < 24) {
            this.hora = hora;
        } else {
            System.out.println("Hora inv?lida.");
        }
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {
        if (minuto >= 0 && minuto < 60) {
            this.minuto = minuto;
        } else {
            System.out.println("Minuto inv?lido.");
        }
    }

    public int getSegundo() {
        return segundo;
    }

    public void setSegundo(int segundo) {
        if (segundo >= 0 && segundo < 60) {
            this.segundo = segundo;
        } else {
            System.out.println("Segundo inv?lido.");
        }
    }

    public boolean isEsDigital() {
        return esDigital;
    }

    public void setEsDigital(boolean esDigital) {
        this.esDigital = esDigital;
    }

    public void mostrarHoraCompleta() {
        System.out.println("Hora actual: " + hora + ":" + minuto + ":" + segundo);
    }

    public void cambiarModo() {
        esDigital = !esDigital;
        System.out.println("Modo cambiado a: " + (esDigital ? "Digital" : "Anal?gico"));
    }

    public void imprimirAtributo(String atributo) {
        switch (atributo.toLowerCase()) {
            case "marca" -> System.out.println("Marca: " + this.marca);
            case "hora" -> System.out.println("Hora: " + this.hora);
            case "minuto" -> System.out.println("Minuto: " + this.minuto);
            case "segundo" -> System.out.println("Segundo: " + this.segundo);
            case "esdigital" -> System.out.println("Es Digital: " + this.esDigital);
            default -> System.out.println("Atributo no encontrado.");
        }
    }
}