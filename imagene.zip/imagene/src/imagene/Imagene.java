package imagene;
import escudofcb.EscudoFCB;
import reloj.Reloj;
import clase.Pelota;
import guitarra.Guitarra;

public class Imagene {

    public static void main(String[] args) {
        // EscudoFCB
        EscudoFCB escudo = new EscudoFCB("Circular", "Azul", "Grana", "M�s que un club", "Cruz y bandera");
        escudo.mostrarEscudo();
        escudo.cambiarColor("Rojo", "Amarillo");
        escudo.mostrarDetalles();

        System.out.println("\n------------------------\n");

        // Reloj
        Reloj reloj = new Reloj("Casio", 13, 45, 20, true);
        reloj.mostrarHoraCompleta();
        reloj.cambiarModo();
        reloj.imprimirAtributo("marca");

        System.out.println("\n------------------------\n");

        // Pelota
        Pelota pelota = new Pelota("Blanca", 22.5, "Cuero", 0.5, "F�tbol");
        pelota.mostrarInformacion();
        pelota.rebotar();
        System.out.println("�Es reglamentaria?: " + (pelota.esReglamentaria() ? "S�" : "No"));

        System.out.println("\n------------------------\n");

        // Guitarra
        Guitarra guitarra = new Guitarra("Juan", 6, 25, "Guitarra El�ctrica", 6);
        guitarra.imprimirInfo();
        guitarra.tocarInstrumento();
    }
}